<template>
    <a href="#"><slot></slot></a>
</template>
