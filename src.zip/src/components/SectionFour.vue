<template>
    <div class="four">
        <div class="content_four">
                <img class="img_card" src="../icons/cards.png" />
            <div class="text_four">
                <h2 class="h2_four">
                    Учите новые слова с помощью карточек
                </h2>
                <p class="parag_four">
                    Рубрики помогут отбирать категории слов под себя и изучать лексику с удовольствием
                </p>
            </div>
        </div>
    </div>
</template>

<style scoped>
.four {
    margin: 0px 100px;
    max-width: 1920px;
}

.content_four {
    text-align: center;
    display: inline-block;
}

.img_card {
    margin-left: 30px;
    height: 300px;
    width: 450px;
}

.text_four {
    float: left;
}

.h2_four {
    font-size: 40px;
    text-align: left;
}

.parag_four {
    font-size: 30px;
    text-align: left;
}
</style>