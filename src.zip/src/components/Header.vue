<script>
import Link from './Link.vue';
import Button from './Button.vue';
import store from "../store/index.js";
import { computed } from "vue";
import { supabase } from "../lib/supabase";
import { useRouter } from "vue-router";


export default {
    components: {
        Link,
        Button,
    },

    setup() {
        // Get user from store
        const user = computed(() => store.state.user);
        // Setup ref to router
        const router = useRouter();
        // Logout function
        const logout = async () => {
            await supabase.auth.signOut();
            router.push({ name: "Main" });
        };
        return { logout, user };
    },

}
</script>

<template>
    <header class="header">
        <section v-if="user" class="auth">
            <router-link class='logo' active-class="active" to="/student" exact>ForeignSkill</router-link>
            <router-link class='link' active-class="active" to="/tests">Тесты</router-link>
            <router-link class='link' active-class="active" to="/cards">Карточки</router-link>
            <router-link class='link' active-class="active" to="/student">Личный кабинет</router-link>
            <button class="btn_signout" @click="logout">Выход</button>
        </section>
        <section v-if="!user" class="no_auth">
            <router-link class='logo' active-class="active" to="/" exact>ForeignSkill</router-link>
            <router-link to="/login">
                ВОЙТИ
            </router-link>
            <router-link to="/sign">
                РЕГИСТРАЦИЯ
            </router-link>
        </section>
    </header>
</template>

<style scoped>  /* @import url('/src/assets/main.css'); */

  .auth,
  .no_auth {
      padding: 30px 200px;
      font-size: 30px;
  }

  .auth {
      background-color: #5C95CD;
  }

  .no_auth {
      display: inline;
      float: left;
  }

  .logo {
      font-size: 40px;
      display: inline;
      color: #ffffff;
      margin-right: 80px;
      text-decoration: none;
      float: left;
  }

  .link {

      text-decoration: none;
      margin-left: 80px;
      color: white;
      padding: 20px 10px;
  }

  .link:hover {
      background-color: #bbcae2;
      border-radius: 10px;
      /* color: #000; */
  }

  .active {
      border-bottom: 1px solid #ffffff;
  }

  .btn_signout {
      background-color: #fff;
      color: black;
      font-size: 25px;
      border: #5C95CD;
      border-radius: 15px;
      padding: 7px 20px;
      font-weight: 600;
      cursor: pointer;
      margin-left: 60px;
  }</style>