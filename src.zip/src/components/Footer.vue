<template>
    <div class="footer">
    <p class="logo_footer">
        ForeignSkill
    </p>
    <p class="rights">
        © all rights reserved
    </p>
    </div>
</template>

<style scoped>
    .footer{
        text-align: center;
        width: 100%;
        height: 140px;
        color:white;
        background-color: #5C95CD;
    }
    .logo_footer{
        font-size: 40px;
        float: left;
        margin: 40px 0px 0px 100px;
        }
    .rights{
         margin: 40px 100px 0px 0px;
        font-size: 30px;
        float: right;
    }
</style>