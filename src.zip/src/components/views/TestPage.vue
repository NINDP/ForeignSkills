<template>
    <p style="font-size: 40px;">  {{ this.$route.params.id }}</p>
     <p>  {{ test.name }}</p>
      <!-- <p>  {{ this.$route.params.count }}</p> -->
    <!-- <h1 class="title_testpage">
        Тест на тему {{ theme }}
    </h1>
    <div class="test_page" v-if="index < count">
        <p class="question">
            {{ questions[index]['question'] }}
        </p>

        <label class="answer" :for="key" v-for="answer, key in questions[index]['answers']" :class="{ 'bg-red-200': selectedAnswer == key },
            { 'bg-green-200': key == questions[index]['correctAnswer'] && selectedAnswer != '' }">

            <input type="radio" :id="key" class="input" :value="key" @change="answered($event)" v-model="selectedAnswer"
                :disabled="selectedAnswer != ''" />
            {{ answer }}
        </label>


        <div>
            <Button class="btn" v-show="selectedAnswer != '' && index < count - 1" @click="nextQuestion">
                Следующий вопрос
            </Button>
            <Button class="btn" v-show="selectedAnswer != '' && index == count - 1" @click="showResults">
                К результату!
            </Button>
        </div>
    </div>
    <div class="results" v-else>
        <img src="../icons/1.png" />
        <h2>Результаты</h2>
        <div>
            <p>
                Количество правильных ответов:
                <span>{{ correctAnswer }}</span>
            </p>
            <p>
                Количество неправильных ответов:
                <span>{{ wrongAnswer }}</span>
            </p>
        </div>
        <Button class="btn after" @click="resetQuiz">
            Пройти тест заново
        </Button>
        <router-link to="/tests">
            <Button class="btn after">
                Вернуться к тестам
            </Button>
        </router-link>
    </div> -->
</template>

<!-- <script>

import Button from '../Button.vue';
export default {
    name:"testPage",
    components: {
        Button
    },
    data() {
        return {
            index: 0,
            selectedAnswer: '',
            correctAnswer: 0,
            wrongAnswer: 0,
            count: 3,
            theme: 'Семья',
            questions: [
                {
                    question: "Как с английского переводится слово \"семья\" ?",
                    answers: { a: 'Family', b: 'Friend', c: 'Fat' },
                    correctAnswer: 'a'
                },
                {
                    question: 'Как переводится фраза "I don\'\ t care"?',
                    answers: { a: 'Я не волнуюсь', b: 'Я не забочусь', c: 'Мне всё равно' },
                    correctAnswer: 'c'
                },
                {
                    question: 'Как на английский переводится слово \"мама\"?',
                    answers: { a: 'Mother', b: 'Mather', c: 'Mahter' },
                    correctAnswer: 'a'
                },
            ]
        }
    },
    methods: {
        answered(e) {
            this.selectedAnswer = e.target.value
            if (this.selectedAnswer == this.questions[this.index]['correctAnswer'])
                this.correctAnswer++
            else
                this.wrongAnswer++
        },
        nextQuestion() {
            this.index++
            this.selectedAnswer = ''
        },
        showResults() {
            this.index++
        },
        resetQuiz() {
            this.index = 0
            this.selectedAnswer = ''
            this.correctAnswer = 0
            this.wrongAnswer = 0
        }
    },
    setup(){
        // const tests = ref([]);
        // const dataLoaded = ref(null);
        // const getTags = async () => {
        //     try {
        //         const { data } = await supabase.from('levels').select('*')
        //         // const { tags, error } = await supabase.from('tags').select('id, name');
        //         if (error) throw error;
        //         data.value = tags;
        //         dataLoaded.value = true;
        //         // проверка
        //         console.log(data.value)
        //     }
        //     catch (error) {
        //         console.warn(error.message)
        //     }
        // }

        // getTags();
    }
} -->

<!-- </script> -->

<script setup>
import { reactive } from 'vue'
import { useRoute } from 'vue-router'
import store from '../../store'
import { supabase } from '../../lib/supabase';
// import supabase from '../../lib/supabase'

const route = useRoute()

let test = reactive({})

const getTest = async (id) => {
    // const found = store.tests.find(x => x.id === parseInt(route.params.id))
    // if (found) {
    //     Object.assign(test, found)
    //     return
    // }
    let { data, error } = await supabase
        .from('tests')
        .select()
        .eq('id', id)
        .single()

    if (error) throw new Error(error)

    Object.assign(test, data)
}


getTest(route.params.id)

</script>

<style scoped>
.btn {
    font-size: 24px;
    border: 2px solid #6EA0D6;
    background-color: white;
    margin: 50px 40px 0px;
    border-radius: 30px;
    padding: 15px 50px;
}

.after {
    margin-bottom: 100px;
}

.input {
    display: block;
    appearance: none;
}

.title_testpage {
    font-size: 50px;
    text-align: center;
}

.test_page {
    margin-left: 30%;
    margin-bottom: 100px;
    border: 1px solid black;
    border-radius: 20px;
    width: 800px;
    height: 500px;
    text-align: center;
}

.question {
    font-size: 30px;
}

.answer {
    display: block;
    /* text-align: center; */
    border: 2px solid gray;
    border-radius: 20px;
    /* width: 600px; */
    height: 40px;
    font-size: 25px;
    cursor: pointer;
    margin: 20px 40px;
}

.bg-red-200 {
    background-color: rgb(230, 106, 106);
}

.bg-green-200 {
    background-color: rgb(108, 197, 108);
}

.results {
    text-align: center;
    font-size: 30px;
}
</style>