<template>
    <button class="btn"><slot></slot></button>
</template>

<style>
  .btn{
    font-weight: bold;
    cursor: pointer;
  }

</style>
